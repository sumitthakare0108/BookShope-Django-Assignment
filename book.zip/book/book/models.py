from pymongo import MongoClient

#class Database:
 # def user(self,ui,ps):
