from django.shortcuts import render
from pymongo import MongoClient
#from models import Database

def home(request):
  return render(request,"index.html")


def addbook(request):
    return render(request,"result.html")

def books(request):
    msg=None
    if request.method=="POST":
     try:
         id=request.POST.get("id")
         ti=request.POST.get("title")
         au=request.POST.get("author")
         ge=request.POST.get("genre")
         py=request.POST.get("published_year")
         i=request.POST.get("isbn")
         pa=request.POST.get("pages")
         la=request.POST.get("language")
         pu=request.POST.get("publisher")

         dic={}
         dic['id']=id
         dic['title']=ti
         dic['author']=au
         dic['genre']=ge
         dic["published_year"]=py
         dic["isbn"]=i
         dic["pages"]=pa
         dic["language"]=la
         dic["publisher"]=pu
         client=MongoClient("mongodb+srv://sumit575:Sumit0108@sumitcluster.pwsnydg.mongodb.net/?retryWrites=true&w=majority&appName=SumitCluster")
         db=client['Sumitdb']
         coll = db["book"]

         print(dic)
         coll.insert_one(dic)
         msg="Book Added Successfully"
     except:
         msg="Error in Insert"

    dic={}
    dic['status']=msg     

    return render(request,"addstatus.html",dic)

def search(request):
   if request.method=="POST":
      fid=request.POST.get("book")
      dic={}
      dic["id"]=fid
      print(dic)
      client=MongoClient("mongodb+srv://sumit575:Sumit0108@sumitcluster.pwsnydg.mongodb.net/?retryWrites=true&w=majority&appName=SumitCluster")
      db=client['Sumitdb']
      collection = db['book']
      for s in collection.find(dic):
        print(s)
   return render(request,"search.html",s)

def devil(request):
   client=MongoClient("mongodb+srv://sumit575:Sumit0108@sumitcluster.pwsnydg.mongodb.net/?retryWrites=true&w=majority&appName=SumitCluster")

   db=client["Sumitdb"]
   collection = db["book"]
   k={}
   for k in collection.find():
    print(k)



   return render(request,"searchbook.html",{'book':k})

def lala(request):
   return render(request,"UpdateBook.html")

def mini(request):
   su=None
   if request.method=="POST":
      try:
         id=request.POST.get('id')
         ti=request.POST.get("title")
         au=request.POST.get("author")
         pa=request.POST.get("pages")
         la=request.POST.get("language")

         n={}
         n['id']=id
         ch={}
         ch['title']=ti
         ch['author']=au
         ch['pages']=pa
         ch['language']=la
         upd={'$set':ch}
         client=MongoClient("mongodb+srv://sumit575:Sumit0108@sumitcluster.pwsnydg.mongodb.net/?retryWrites=true&w=majority&appName=SumitCluster")
         db=client['Sumitdb']
         coll = db["book"]
         coll.update_one(n,upd)
         print("update succesfully")
         su=("Update Succesfully")
      except:
         print("error")
         su=("Error In Update")

      dic={}  
      dic['status']=su 
   
   return render(request,"UpdateStatus.html",dic)

def dele(request):
   return render(request,"DeleteBook.html")

def delbook(request):
   if request.method=="POST":
      try:
         id=request.POST.get('bookid')
         dic={}
         dic["bookid"]=id
         print(dic)

         client=MongoClient("mongodb+srv://sumit575:Sumit0108@sumitcluster.pwsnydg.mongodb.net/?retryWrites=true&w=majority&appName=SumitCluster")
         db=client['Sumitdb']
         collection = db['book']
         collection.delete_one(dic)
         print("delete succesfully")
         msg=("Deleted Succesfully")
      except:
         print("error in code")   
         msg=("Book Not Found")

      dic={}
      dic["status"]=msg

      
   return render(request,"DeleteStatus.html",dic)

def about(request):
   return render(request,"about.html")